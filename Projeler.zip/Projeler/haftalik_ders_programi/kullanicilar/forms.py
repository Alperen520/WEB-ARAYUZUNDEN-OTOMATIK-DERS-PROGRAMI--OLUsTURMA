from django import forms
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import get_user_model

User = get_user_model()

class LoginForm(AuthenticationForm):
    username = forms.CharField(
        label='Kullanıcı Adı',
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    password = forms.CharField(
        label='Şifre',
        widget=forms.PasswordInput(attrs={'class': 'form-control'})
    )

class RegisterForm(forms.ModelForm):
    password1 = forms.CharField(label='Şifre', widget=forms.PasswordInput)
    password2 = forms.CharField(label='Şifre (Tekrar)', widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ['username', 'email']

    def clean(self):
        cleaned_data = super().clean()

        # Şifre uyuşması
        if cleaned_data.get('password1') != cleaned_data.get('password2'):
            self.add_error('password2', "Şifreler uyuşmuyor.")

        # E-posta domain kontrolü
        email = cleaned_data.get('email', '').lower()
        if not email.endswith('@kocaelisaglik.edu.tr'):
            self.add_error('email', "Sadece '@kocaelisaglik.edu.tr' uzantılı e-posta kabul edilir.")

        return cleaned_data

    def save(self, commit=True):
        user = super().save(commit=False)
        email = self.cleaned_data.get("email", "").strip().lower()
    
        if email:
            try:
                local, domain = email.split("@")
            except ValueError:
                raise forms.ValidationError("Geçersiz e-posta adresi.")

            if domain == "kocaelisaglik.edu.tr":
                if local.startswith("akd"):
                    user.rol = "akademisyen"
                elif local.isdigit() and len(local) <= 9:
                    user.rol = "ogrenci"
                else:
                    raise forms.ValidationError("Rol atanamadı. 'akd' ile başlamıyor veya öğrenci numarası değil.")
            else:
                raise forms.ValidationError("Kurumsal e-posta (@kocaelisaglik.edu.tr) giriniz.")
        else:
            raise forms.ValidationError("E-posta adresi girilmedi.")

        if commit:
            user.save()
        return user

