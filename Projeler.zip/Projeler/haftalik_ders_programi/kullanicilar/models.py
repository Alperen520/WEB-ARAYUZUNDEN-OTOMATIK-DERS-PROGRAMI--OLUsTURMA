#kullanicilar/models.py
from django.contrib.auth.models import AbstractUser
from django.db import models

ROLLER = [
    ('admin', 'Admin'),
    ('akademisyen', 'Akademisyen'),
    ('ogrenci', 'Öğrenci'),
]

class User(AbstractUser):
    rol = models.CharField(max_length=20, choices=ROLLER)
    bolum = models.ForeignKey('bolumler.Bolum', on_delete=models.SET_NULL, null=True, blank=True)
    donem = models.PositiveIntegerField(null=True, blank=True)

    def get_ogrenci_profili(self):
        if self.rol == "ogrenci":
            try:
                from bolumler.models import Ogrenci  # bu import runtime'da yapılır
                return Ogrenci.objects.get(numara=self.username)
            except:
                return None
        return None
