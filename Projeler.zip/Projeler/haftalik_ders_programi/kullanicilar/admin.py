# kullanicilar/admin.py
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User

class CustomUserAdmin(UserAdmin):
    fieldsets = UserAdmin.fieldsets + (
        ("Ek Alanlar", {"fields": ("rol",)}),
    )
    add_fieldsets = UserAdmin.add_fieldsets + (
        ("Ek Alanlar", {"fields": ("rol",)}),
    )
    list_display = ("username", "email", "rol", "is_staff", "is_superuser")
    list_filter = ("rol", "is_staff", "is_superuser")

admin.site.register(User, CustomUserAdmin)
