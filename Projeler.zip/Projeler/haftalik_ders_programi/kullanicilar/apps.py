# apps.py
from django.apps import AppConfig

class KullanicilarConfig(AppConfig):
    name = 'kullanicilar'
