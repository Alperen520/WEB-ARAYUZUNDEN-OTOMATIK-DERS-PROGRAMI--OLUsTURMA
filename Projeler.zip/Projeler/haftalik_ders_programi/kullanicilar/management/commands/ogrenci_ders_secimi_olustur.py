from django.core.management.base import BaseCommand
from bolumler.models import Ogrenci, Ders, OgrenciDersSecimi

class Command(BaseCommand):
    help = "Bilgisayar Mühendisliği öğrencilerine otomatik ders seçimi atar."

    def handle(self, *args, **options):
        ogrenciler = Ogrenci.objects.filter(bolum__ad__iexact="bilgisayar mühendisliği")

        sayac = 0
        for ogrenci in ogrenciler:
            dersler = Ders.objects.filter(
                bolum=ogrenci.bolum,
                donem=ogrenci.donem,
                zorunluluk="zorunlu"
            )
            for ders in dersler:
                secim, created = OgrenciDersSecimi.objects.get_or_create(
                    ogrenci=ogrenci,
                    ders=ders,
                    defaults={"alttan": False}
                )
                if created:
                    sayac += 1

        self.stdout.write(self.style.SUCCESS(f"✅ Toplam {sayac} ders seçimi kaydı başarıyla oluşturuldu."))
