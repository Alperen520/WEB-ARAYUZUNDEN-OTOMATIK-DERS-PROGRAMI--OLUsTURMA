from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from bolumler.models import Bolum, Ogrenci
from faker import Faker

class Command(BaseCommand):
    help = 'Her döneme 50 öğrenci ekler (bilgisayar mühendisliği)'

    def handle(self, *args, **kwargs):
        User = get_user_model()
        faker = Faker("tr_TR")

        try:
            bolum = Bolum.objects.get(ad__iexact="bilgisayar mühendisliği")
        except Bolum.DoesNotExist:
            self.stdout.write(self.style.ERROR("❌ Bölüm bulunamadı: bilgisayar mühendisliği"))
            return

        numara_sayaci = 1000
        for donem in range(1, 9):
            for _ in range(50):
                numara = f"{numara_sayaci:08d}"
                isim = faker.first_name()
                soyisim = faker.last_name()
                email = f"{numara}@kocaelisaglik.edu.tr"
                password = numara

                if not User.objects.filter(username=numara).exists():
                    user = User.objects.create_user(
                        username=numara,
                        email=email,
                        password=password,
                        rol="ogrenci",
                        bolum=bolum,
                        donem=donem,
                        is_active=True
                    )

                    Ogrenci.objects.create(
                        numara=numara,
                        isim=isim,
                        soyisim=soyisim,
                        donem=donem,
                        bolum=bolum,
                        kullanici_sifre=password
                    )

                numara_sayaci += 1

        self.stdout.write(self.style.SUCCESS("✅ Her döneme 50 öğrenci başarıyla eklendi."))
