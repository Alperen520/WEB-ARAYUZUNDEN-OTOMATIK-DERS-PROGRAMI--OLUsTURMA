from django.shortcuts import render
from django.urls import path
from . import views


urlpatterns = [

    path('giris/', views.giris_yap, name='giris'),
    path('cikis/', views.cikis_yap, name='cikis'),
    path('admin-paneli/', views.admin_paneli, name='admin_paneli'),
    path('akademisyen-paneli/', views.akademisyen_paneli, name='akademisyen_paneli'),

    path('ogrenci-paneli/', views.ogrenci_paneli, name='ogrenci_paneli'),
    path('', views.anasayfa, name='anasayfa'),
    
    path('akademisyen/ders-onay/', views.onay_bekleyen_dersler, name='ders_onay'),
    path('akademisyen/ders-onayla/', views.ders_onayla, name='ders_onayla'),

]


