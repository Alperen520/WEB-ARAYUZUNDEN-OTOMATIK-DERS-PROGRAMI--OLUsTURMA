from django.contrib.auth import login, logout, authenticate
from django.shortcuts import render, redirect
from .forms import LoginForm,RegisterForm
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.shortcuts import render, redirect
from bolumler.models import Ders, OgrenciDersSecimi




def giris_yap(request):
    if request.method == 'POST':
        form = LoginForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)

            # Kullanıcının rolüne göre yönlendirme yap
            if user.rol == 'admin':
                return redirect('admin_paneli')
            elif user.rol == 'akademisyen':
                return redirect('akademisyen_paneli')
            elif user.rol == 'ogrenci':
                return redirect('ogrenci_paneli')
            else:
                return redirect('anasayfa')
        else:
            # <<< BURASI >>>
            messages.error(request, "Kullanıcı adı veya şifre hatalı!")  # ← bunu buraya ekle
    else:
        form = LoginForm()
    return render(request, 'kullanicilar/giris.html', {'form': form})


@login_required
def cikis_yap(request):
    logout(request)
    return redirect('giris')

# Panel görünümleri (gerekirse geçici olarak buradan render edilir)
@login_required
def admin_paneli(request):
    return render(request, 'kullanicilar/admin_paneli.html')

@login_required
def akademisyen_paneli(request):
    return render(request, 'kullanicilar/akademisyen_paneli.html')

from bolumler.models import Ogrenci

@login_required
def ogrenci_paneli(request):
    user = request.user
    ogrenci = Ogrenci.objects.filter(numara=user.username).first()

    context = {
        "kullanici": user,
        "ogrenci": ogrenci,
    }
    return render(request, "kullanicilar/ogrenci_paneli.html", context)


@login_required
def anasayfa(request):
    return render(request, 'kullanicilar/anasayfa.html')




def kayit_ol(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Kayıt başarılı! Giriş yapabilirsiniz.")
            return redirect('giris')
    else:
        form = RegisterForm()
    return render(request, 'kullanicilar/kayit.html', {'form': form})


def ogrenci_ders_sec(request):
    ogrenci = request.user.ogrenci  # öğrenci modeliyle ilişkilendirdik
    alttan_ders_sayisi = OgrenciDersSecimi.objects.filter(ogrenci=ogrenci, alttan=True).count()
    max_ects = 45 if alttan_ders_sayisi > 0 else 30

    # Ders seçimi yapılırsa kontrol et
    if request.method == "POST":
        secilen_dersler = request.POST.getlist("dersler")  # checkbox isimleri
        toplam_ects = sum(Ders.objects.get(id=id).ects for id in secilen_dersler)
        if toplam_ects > max_ects:
            return render(request, "ogrenci/ders_sec.html", {
                "hata": f"Maksimum {max_ects} ECTS'lik ders seçebilirsiniz."
            })
        else:
            # Eski seçimleri sil
            OgrenciDersSecimi.objects.filter(ogrenci=ogrenci).delete()
            for ders_id in secilen_dersler:
                OgrenciDersSecimi.objects.create(ogrenci=ogrenci, ders_id=ders_id)
            return redirect("ders_sec_basarili")

    # GET isteği için mevcut dersleri getir
    donem_dersleri = Ders.objects.filter(donem=ogrenci.donem)
    alttan_dersler = Ders.objects.filter(id__in=...)  # varsa alttan

    return render(request, "ogrenci/ders_sec.html", {
        "donem_dersleri": donem_dersleri,
        "alttan_dersler": alttan_dersler,
        "max_ects": max_ects
    })


from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from bolumler.models import Ogrenci, OgrenciDersSecimi, DersSecimOnay

@login_required
def onay_bekleyen_dersler(request):
    user = request.user
    if user.rol != 'akademisyen':
        return redirect('anasayfa')

    ogrenciler = Ogrenci.objects.filter(
        bolum=user.bolum,
        donem=user.donem
    )

    onay_kayitlari = []
    for ogrenci in ogrenciler:
        ders_secimleri = OgrenciDersSecimi.objects.filter(ogrenci=ogrenci)
        onay_kaydi, _ = DersSecimOnay.objects.get_or_create(ogrenci=ogrenci, akademisyen=user)
        onay_kayitlari.append({
            'ogrenci': ogrenci,
            'dersler': ders_secimleri,
            'onay': onay_kaydi
        })

    return render(request, "akademisyen/onay_bekleyen_dersler.html", {
        'onay_kayitlari': onay_kayitlari
    })
