from django.urls import path
from . import views

urlpatterns = [
    path("ders-programi/", views.ders_programi_olustur_view, name="ders_programi"),
    path("ders-programi/dosyalar/", views.ders_programi_dosya_liste_view, name="ders_programi_dosyalar"),
    path("ders-programi/excel/<str:dosya_adi>/", views.ders_programi_excel_indir_dosya, name="ders_programi_excel_indir_dosya"),
]
