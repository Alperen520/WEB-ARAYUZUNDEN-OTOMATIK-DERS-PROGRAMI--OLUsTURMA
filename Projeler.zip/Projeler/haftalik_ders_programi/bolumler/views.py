# bolumler/views.py

from django.contrib.admin.views.decorators import staff_member_required
from django.shortcuts import render
from django.contrib import messages
from django.conf import settings
from django.http import FileResponse, Http404
from .forms import DersProgramiFiltreForm
from .utils import ders_programi_olustur, export_ders_programi_to_excel_static
from .models import Bolum
import os

@staff_member_required
def ders_programi_olustur_view(request):
    form = DersProgramiFiltreForm(request.POST or None)
    olusan_dosya = None

    if request.method == "POST" and form.is_valid():
        donem = int(form.cleaned_data["donem"])

        # Otomatik bölümleri çek (Bilgisayar ve Yazılım Mühendisliği)
        bilgisayar_bolumu = Bolum.objects.filter(ad__icontains="bilgisayar").first()
        yazilim_bolumu = Bolum.objects.filter(ad__icontains="yazılım").first()
        hedef_bolumler = [b for b in [bilgisayar_bolumu, yazilim_bolumu] if b]

        # Seçilen döneme göre ilgili sınıfların dönemleri (tek = güz, çift = bahar)
        if donem % 2 == 1:
            donemler = [1, 3, 5, 7]
        else:
            donemler = [2, 4, 6, 8]

        # 1) Veritabanına atamaları yap
        ders_programi_olustur(bolumler=hedef_bolumler, donemler=donemler)

        # 2) Excel çıktısı oluştur
        olusan_dosya = export_ders_programi_to_excel_static(bolumler=hedef_bolumler, donemler=donemler)

        messages.success(request, f"Ders programı oluşturuldu ve Excel dosyası üretildi: {olusan_dosya}")

    return render(request, "bolumler/ders_programi.html", {
        "form": form,
        "olusan_dosya": olusan_dosya,
    })


def ders_programi_dosyalari_listele():
    klasor_yolu = os.path.join(settings.BASE_DIR, "static", "ders_programlari")
    if not os.path.exists(klasor_yolu):
        return []
    return [dosya for dosya in os.listdir(klasor_yolu) if dosya.endswith(".xlsx")]


@staff_member_required
def ders_programi_dosya_liste_view(request):
    dosyalar = ders_programi_dosyalari_listele()
    return render(request, "bolumler/ders_programi_dosyalar.html", {"dosyalar": dosyalar})


@staff_member_required
def ders_programi_excel_indir_dosya(request, dosya_adi):
    dosya_yolu = os.path.join(settings.BASE_DIR, "static", "ders_programlari", dosya_adi)
    if not os.path.exists(dosya_yolu):
        raise Http404("Dosya bulunamadı.")
    return FileResponse(open(dosya_yolu, "rb"), as_attachment=True, filename=dosya_adi)
