from django.db import models

# Sabit gunler listesi
GUNLER = [
    ('Pazartesi', 'Pazartesi'),
    ('Salı', 'Salı'),
    ('Çarşamba', 'Çarşamba'),
    ('Perşembe', 'Perşembe'),
    ('Cuma', 'Cuma'),
    ('Cumartesi', 'Cumartesi'),
    ('Pazar', 'Pazar'),
]

class Bolum(models.Model):
    ad = models.CharField(max_length=100)

    def __str__(self):
        return self.ad

class Ders(models.Model):
    DERS_TIPLERI = [
        ('yuz_yuze', 'Yüz Yüze'),
        ('online', 'Online'),
        ('uygulamali', 'Uygulamalı'),
        ('proje', 'Proje'),
    ]

    ZORUNLULUK = [
        ('zorunlu', 'Zorunlu'),
        ('secimli', 'Seçmeli'),
    ]

    ad = models.CharField(max_length=100)
    bolum = models.ForeignKey(Bolum, on_delete=models.CASCADE)
    akademisyenler = models.ManyToManyField(
        'kullanicilar.User',
        limit_choices_to={'rol': 'akademisyen'},
        related_name='verilen_dersler',
        blank=True
    )
    ders_tipleri = models.CharField(max_length=50, choices=DERS_TIPLERI, default='yuz_yuze')
    zorunluluk = models.CharField(max_length=20, choices=ZORUNLULUK, default='zorunlu')
    ders_no = models.CharField(max_length=20)
    katalog_no = models.CharField(max_length=20)
    kodu = models.CharField(max_length=20)
    donem = models.PositiveIntegerField()
    teorik_saat = models.PositiveIntegerField()
    uygulama_saat = models.PositiveIntegerField()
    ects = models.PositiveIntegerField()

    def __str__(self):
        return f"{self.kodu} - {self.ad}"

class Derslik(models.Model):
    STATU_SECENEKLERI = [
        ('normal', 'Normal'),
        ('lab', 'Laboratuvar'),
    ]

    ad = models.CharField(max_length=100)
    kapasite = models.PositiveIntegerField()
    statu = models.CharField(max_length=10, choices=STATU_SECENEKLERI, default='normal')

    def __str__(self):
        return f"{self.ad} (Kapasite: {self.kapasite}, Statü: {self.get_statu_display()})"

class ZamanAraligi(models.Model):
    akademisyen = models.ForeignKey(
        'kullanicilar.User',
        on_delete=models.CASCADE,
        limit_choices_to={'rol': 'akademisyen'}
    )
    gun = models.CharField(max_length=10, choices=GUNLER)
    baslangic = models.TimeField()
    bitis = models.TimeField()

    def __str__(self):
        return f"{self.akademisyen.username} - {self.gun} {self.baslangic}-{self.bitis}"

class AkademisyenZamani(models.Model):
    akademisyen = models.ForeignKey(
        'kullanicilar.User',
        on_delete=models.CASCADE,
        limit_choices_to={'rol': 'akademisyen'}
    )
    gun = models.CharField(max_length=15)
    baslangic_saati = models.TimeField()
    bitis_saati = models.TimeField()

    def __str__(self):
        return f"{self.akademisyen} - {self.gun} ({self.baslangic_saati} - {self.bitis_saati})"

class AkademisyenDersAtama(models.Model):
    akademisyen = models.ForeignKey(
        'kullanicilar.User',
        on_delete=models.CASCADE,
        limit_choices_to={'rol': 'akademisyen'}
    )
    ders = models.ForeignKey(Ders, on_delete=models.CASCADE)

    class Meta:
        unique_together = ('akademisyen', 'ders')

    def __str__(self):
        return f"{self.akademisyen.username} - {self.ders.ad}"

class Akademisyen(models.Model):
    DERECE_SECENEKLERI = [
        ("Prof. Dr.", "Prof. Dr."),
        ("Doç. Dr.", "Doç. Dr."),
        ("Dr. Öğr. Üyesi", "Dr. Öğr. Üyesi"),
        ("Arş. Gör.", "Arş. Gör."),
    ]

    user = models.OneToOneField(
        'kullanicilar.User',
        on_delete=models.CASCADE,
        limit_choices_to={'rol': 'akademisyen'}
    )
    isim_soyisim = models.CharField(max_length=100)
    derece = models.CharField(max_length=30, choices=DERECE_SECENEKLERI)
    verdigi_dersler = models.ManyToManyField(Ders, blank=True)

    def __str__(self):
        return f"{self.derece} {self.isim_soyisim}"

class Ogrenci(models.Model):
    numara = models.CharField(max_length=20, unique=True)
    isim = models.CharField(max_length=100)
    soyisim = models.CharField(max_length=100)
    donem = models.PositiveIntegerField()
    bolum = models.ForeignKey(Bolum, on_delete=models.CASCADE, null=True, blank=True)
    kullanici_sifre = models.CharField("Kullanıcı Şifresi", max_length=128, blank=True)

    def __str__(self):
        return f"{self.numara} - {self.isim} {self.soyisim}"

    class Meta:
        db_table = "bolumler_ogrenci"

class OgrenciDersSecimi(models.Model):
    ogrenci = models.ForeignKey("Ogrenci", on_delete=models.CASCADE)
    ders = models.ForeignKey("Ders", on_delete=models.CASCADE)
    alttan = models.BooleanField(default=False)

    class Meta:
        unique_together = ("ogrenci", "ders")

class BasarisizDers(models.Model):
    ogrenci = models.ForeignKey(
        'kullanicilar.User',
        on_delete=models.CASCADE,
        limit_choices_to={'rol': 'ogrenci'}
    )
    ders = models.ForeignKey(Ders, on_delete=models.CASCADE)
    not_durumu = models.CharField(max_length=50, default="FF")

    class Meta:
        unique_together = ('ogrenci', 'ders')

    def __str__(self):
        return f"{self.ogrenci.username} - {self.ders.ad} ({self.not_durumu})"

class SinifSorumlusu(models.Model):
    bolum = models.ForeignKey(Bolum, on_delete=models.CASCADE, related_name="sinif_sorumlulari")
    donem = models.PositiveIntegerField()
    akademisyen = models.ForeignKey(
        'kullanicilar.User',
        on_delete=models.CASCADE,
        limit_choices_to={'rol': 'akademisyen'},
        related_name="sorumlu_oldugu_siniflar"
    )

    class Meta:
        unique_together = ('bolum', 'donem')

    def __str__(self):
        return f"{self.bolum.ad} {self.donem}. Dönem - {self.akademisyen.get_full_name()}"

class DersSecimOnay(models.Model):
    ogrenci = models.ForeignKey("Ogrenci", on_delete=models.CASCADE)
    akademisyen = models.ForeignKey('kullanicilar.User', on_delete=models.CASCADE, limit_choices_to={'rol': 'akademisyen'})
    onaylandi = models.BooleanField(default=False)
    tarih = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.ogrenci} - {self.akademisyen} - {'Onaylandı' if self.onaylandi else 'Beklemede'}"

from django.contrib.auth import get_user_model
User = get_user_model()

class DersAtama(models.Model):
    ders = models.ForeignKey(Ders, on_delete=models.CASCADE)
    derslik = models.ForeignKey(Derslik, on_delete=models.CASCADE)
    akademisyen = models.ForeignKey(User, on_delete=models.CASCADE, limit_choices_to={'rol': 'akademisyen'})
    gun = models.CharField(max_length=15, choices=GUNLER)
    baslangic = models.TimeField()
    bitis = models.TimeField()

    class Meta:
        unique_together = ('derslik', 'gun', 'baslangic', 'bitis')

    def __str__(self):
        return f"{self.ders} - {self.derslik} - {self.gun} {self.baslangic}-{self.bitis}"
