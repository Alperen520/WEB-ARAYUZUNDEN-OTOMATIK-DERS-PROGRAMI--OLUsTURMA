#bolumler/admin.py
from django.contrib import admin
from .models import (
    Bolum,
    Ders,
    Derslik,
    ZamanAraligi,
    AkademisyenZamani,
    AkademisyenDersAtama,
    Akademisyen,
    Ogrenci,
    BasarisizDers,
    OgrenciDersSecimi
)
from kullanicilar.models import User


@admin.register(Bolum)
class BolumAdmin(admin.ModelAdmin):
    list_display = ("ad",)


@admin.register(Ders)
class DersAdmin(admin.ModelAdmin):
    list_display = (
        "kodu", "ad", "bolum", "donem", "zorunluluk", 
        "ders_tipleri", "teorik_saat", "uygulama_saat", "ects"
    )
    list_filter = ("bolum", "donem", "zorunluluk", "ders_tipleri")
    filter_horizontal = ("akademisyenler",)
    search_fields = ("ad", "kodu", "katalog_no", "ders_no")


@admin.register(Derslik)
class DerslikAdmin(admin.ModelAdmin):
    list_display = ("ad", "kapasite", "statu")
    list_filter = ("statu",)


@admin.register(ZamanAraligi)
class ZamanAraligiAdmin(admin.ModelAdmin):
    list_display = ("akademisyen", "gun", "baslangic", "bitis")
    list_filter = ("gun",)


@admin.register(AkademisyenZamani)
class AkademisyenZamaniAdmin(admin.ModelAdmin):
    list_display = ("akademisyen", "gun", "baslangic_saati", "bitis_saati")
    list_filter = ("gun",)


@admin.register(AkademisyenDersAtama)
class AkademisyenDersAtamaAdmin(admin.ModelAdmin):
    list_display = ("akademisyen", "ders")
    list_filter = ("akademisyen", "ders")


@admin.register(Akademisyen)
class AkademisyenAdmin(admin.ModelAdmin):
    list_display = ("isim_soyisim", "derece", "user")
    list_filter = ("derece",)
    filter_horizontal = ("verdigi_dersler",)
    search_fields = ("isim_soyisim", "user__username")


@admin.register(Ogrenci)
class OgrenciAdmin(admin.ModelAdmin):
    list_display = ("numara", "isim", "soyisim", "donem", "bolum")
    list_filter = ("bolum", "donem")
    search_fields = ("numara", "isim", "soyisim")
    fields = ("numara", "isim", "soyisim", "donem", "bolum", "kullanici_sifre")

    def save_model(self, request, obj, form, change):
        super().save_model(request, obj, form, change)

        # User modeline kullanıcı ekle (zaten yoksa)
        if not User.objects.filter(username=obj.numara).exists():
            User.objects.create_user(
                username=obj.numara,
                email=f"{obj.numara}@kocaelisaglik.edu.tr",
                password=form.cleaned_data.get("kullanici_sifre") or "admin123",
                rol="ogrenci",
                bolum=obj.bolum,
                donem=obj.donem
            )


@admin.register(BasarisizDers)
class BasarisizDersAdmin(admin.ModelAdmin):
    list_display = ("ogrenci", "ders", "not_durumu")
    list_filter = ("not_durumu",)


@admin.register(OgrenciDersSecimi)
class OgrenciDersSecimiAdmin(admin.ModelAdmin):
    list_display = ("ogrenci", "ders", "alttan")
    list_filter = ("alttan",)

from .models import SinifSorumlusu

@admin.register(SinifSorumlusu)
class SinifSorumlusuAdmin(admin.ModelAdmin):
    list_display = ("bolum", "donem", "akademisyen")
    list_filter = ("bolum", "donem")

from .models import DersAtama

@admin.register(DersAtama)
class DersAtamaAdmin(admin.ModelAdmin):
    list_display = ("ders", "derslik", "akademisyen", "gun", "baslangic", "bitis")
    list_filter = ("gun", "derslik")


from django.contrib import admin
from django.urls import reverse
from django.utils.html import format_html
from django.utils.translation import gettext_lazy as _

class CustomAdminSite(admin.AdminSite):
    site_header = "Yönetim Paneli"
    site_title = "Ders Programı Admin"
    index_title = "Kontrol Paneli"

    def index(self, request, extra_context=None):
        if extra_context is None:
            extra_context = {}
        extra_context['ders_programi_link'] = reverse('ders_programi')
        return super().index(request, extra_context=extra_context)

# Custom site'i tanımla
admin_site = CustomAdminSite(name='custom_admin')
