from django.core.management.base import BaseCommand
from bolumler.models import Ogrenci, Ders, OgrenciDersSecimi, BasarisizDers
from django.db import IntegrityError

class Command(BaseCommand):
    help = "Tüm öğrenciler için otomatik ders seçimlerini (zorunlu + alttan + seçmeli) 30 ECTS olacak şekilde yapar."

    def handle(self, *args, **options):
        toplam_eklenen = 0
        ogrenciler = Ogrenci.objects.all()

        for ogr in ogrenciler:
            mevcut_ects = 0
            ders_listesi = []

            # 1. Zorunlu dersleri al (kendi döneminden)
            zorunlu_dersler = Ders.objects.filter(
                bolum=ogr.bolum,
                donem=ogr.donem,
                zorunluluk='zorunlu'
            )

            for ders in zorunlu_dersler:
                ders_listesi.append((ders, False))  # alttan = False
                mevcut_ects += ders.ects

            # 2. Alttan dersleri al
            alttan_ders_ids = BasarisizDers.objects.filter(
                ogrenci__username=ogr.numara
            ).values_list('ders', flat=True)
            alttan_dersler = Ders.objects.filter(id__in=alttan_ders_ids)

            for ders in alttan_dersler:
                if ders not in [d[0] for d in ders_listesi]:
                    ders_listesi.append((ders, True))  # alttan = True
                    mevcut_ects += ders.ects

            # 3. ECTS toplamı 30'dan azsa seçmeli derslerden ekle
            if mevcut_ects < 30:
                secmeli_dersler = Ders.objects.filter(
                    bolum=ogr.bolum,
                    donem=ogr.donem,
                    zorunluluk='secimli'
                )
                for ders in secmeli_dersler:
                    if ders not in [d[0] for d in ders_listesi]:
                        ders_listesi.append((ders, False))
                        mevcut_ects += ders.ects
                        if mevcut_ects >= 30:
                            break

            # 4. Dersleri kaydet (OgrenciDersSecimi olarak)
            for ders, alttan_mi in ders_listesi:
                try:
                    secim, created = OgrenciDersSecimi.objects.get_or_create(
                        ogrenci=ogr,
                        ders=ders,
                        defaults={"alttan": alttan_mi}
                    )
                    if created:
                        toplam_eklenen += 1
                        self.stdout.write(f"{ogr} -> {ders.kodu} ({'Alttan' if alttan_mi else 'Yeni'}) eklendi")
                except IntegrityError:
                    continue

        self.stdout.write(self.style.SUCCESS(f"Toplam {toplam_eklenen} ders ataması yapıldı."))
