from datetime import time, datetime
from collections import defaultdict
from django.db import transaction
from bolumler.models import Ders, Derslik, ZamanAraligi, DersAtama, OgrenciDersSecimi
import os
import openpyxl
from openpyxl.styles import Alignment, Font
from django.conf import settings


def ders_programi_olustur(bolumler, donemler):
    DersAtama.objects.filter(ders__bolum__in=bolumler, ders__donem__in=donemler).delete()

    saat_bloklari = [
        (time(9, 0), time(10, 0)),
        (time(10, 0), time(11, 0)),
        (time(11, 0), time(12, 0)),
        (time(13, 0), time(14, 0)),
        (time(14, 0), time(15, 0)),
        (time(15, 0), time(16, 0)),
        (time(16, 0), time(17, 0)),
        (time(17, 0), time(18, 0))
    ]
    gunler = ['Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma']

    atanan_dersler = []
    kullanilan_akademisyenler = defaultdict(list)
    kullanilan_donem_saat = defaultdict(list)

    for bolum in bolumler:
        dersler = Ders.objects.filter(bolum=bolum, donem__in=donemler).order_by('donem')

        for ders in dersler:
            ogrenci_sayisi = OgrenciDersSecimi.objects.filter(ders=ders).count()
            akademisyen = ders.akademisyenler.first()
            if not akademisyen:
                print(f"⚠️ {ders.ad} dersi ({bolum.ad}) için akademisyen atanmadı.")
                continue

            atandi = False

            for gun in gunler:
                for bas, bit in saat_bloklari:
                    if not ZamanAraligi.objects.filter(
                        akademisyen=akademisyen,
                        gun=gun,
                        baslangic__lte=bas,
                        bitis__gte=bit
                    ).exists():
                        continue

                    if akademisyen.id in kullanilan_akademisyenler[(gun, bas)]:
                        continue
                    if ders.donem in kullanilan_donem_saat[(gun, bas)]:
                        continue
                    if DersAtama.objects.filter(
                        ders__donem=ders.donem,
                        ders__bolum=bolum,
                        gun=gun,
                        baslangic__lt=bit,
                        bitis__gt=bas
                    ).exists():
                        continue

                    # Her saat diliminde derslik eşlemesi yapılır
                    uygun_derslik = None
                    alternatif_derslik = None
                    derslikler = Derslik.objects.all()

                    for d in sorted(derslikler, key=lambda x: x.kapasite):
                        if ders.ders_tipleri == "uygulamali" and d.statu != "lab":
                            continue
                        if ogrenci_sayisi > d.kapasite:
                            continue
                        if DersAtama.objects.filter(
                            derslik=d,
                            gun=gun,
                            baslangic__lt=bit,
                            bitis__gt=bas
                        ).exists():
                            continue
                        if ogrenci_sayisi >= d.kapasite * 0.75:
                            uygun_derslik = d
                            break
                        elif alternatif_derslik is None:
                            alternatif_derslik = d

                    if not uygun_derslik:
                        uygun_derslik = alternatif_derslik

                    if not uygun_derslik:
                        continue

                    with transaction.atomic():
                        atama = DersAtama.objects.create(
                            ders=ders,
                            derslik=uygun_derslik,
                            akademisyen=akademisyen,
                            gun=gun,
                            baslangic=bas,
                            bitis=bit
                        )

                    atanan_dersler.append(atama)
                    kullanilan_akademisyenler[(gun, bas)].append(akademisyen.id)
                    kullanilan_donem_saat[(gun, bas)].append(ders.donem)
                    atandi = True
                    break
                if atandi:
                    break

            if not atandi:
                print(f"⚠️ {ders.ad} dersi ({bolum.ad} - {ders.donem}. dönem) için uygun zaman/derslik bulunamadı.")

    return atanan_dersler


def export_ders_programi_to_excel_static(bolumler, donemler):
    sablon_path = os.path.join(
        settings.BASE_DIR, "bolumler", "static", "ders_programlari", "sablon", "BOŞ_BÜTÜNLEŞİK_ŞABLON.xlsx"
    )
    if not os.path.exists(sablon_path):
        raise FileNotFoundError("Şablon dosyası bulunamadı!")

    wb = openpyxl.load_workbook(sablon_path)
    orijinal_sayfa = wb.active

    gunler = ['Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma']
    saatler = [
        "09:00-10:00", "10:00-11:00", "11:00-12:00",
        "12:00-13:00", "13:00-14:00", "14:00-15:00",
        "15:00-16:00", "16:00-17:00"
    ]

    gun_baslangic_satirlari = {
        'Pazartesi': 4,
        'Salı': 12,
        'Çarşamba': 20,
        'Perşembe': 28,
        'Cuma': 36
    }

    donem_sutun_map = {
        1: 3, 2: 4, 3: 5, 4: 6,
        5: 3, 6: 4, 7: 5, 8: 6,
    }

    for bolum in bolumler:
        ws = wb.copy_worksheet(orijinal_sayfa)
        ws.title = bolum.ad[:31]

        atamalar = DersAtama.objects.filter(ders__bolum=bolum, ders__donem__in=donemler)

        for atama in atamalar:
            gun = atama.gun
            baslangic = atama.baslangic.strftime("%H:%M")
            bitis = atama.bitis.strftime("%H:%M")
            saat_araligi = f"{baslangic}-{bitis}"

            if gun not in gun_baslangic_satirlari or saat_araligi not in saatler:
                continue

            satir = gun_baslangic_satirlari[gun] + saatler.index(saat_araligi)
            sutun = donem_sutun_map.get(atama.ders.donem)
            if not sutun:
                continue

            hucre = ws.cell(row=satir, column=sutun)

            if hucre.value:
                print(f"⚠️ {bolum.ad} - {gun} {saat_araligi} {atama.ders.donem}. dönem hücresine birden fazla ders yazılmak istendi. Atlandı.")
                continue

            icerik = f"{atama.ders.ad}\n{atama.akademisyen.get_full_name()}\n{atama.derslik.ad}"
            hucre.value = icerik
            hucre.alignment = Alignment(wrap_text=True, horizontal="center", vertical="center")
            hucre.font = Font(size=9)

    wb.remove(orijinal_sayfa)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    dosya_adi = f"tum_bolumler_ders_programi_{timestamp}.xlsx"
    cikti_path = os.path.join(settings.BASE_DIR, "static", "ders_programlari", dosya_adi)
    os.makedirs(os.path.dirname(cikti_path), exist_ok=True)
    wb.save(cikti_path)

    return dosya_adi
