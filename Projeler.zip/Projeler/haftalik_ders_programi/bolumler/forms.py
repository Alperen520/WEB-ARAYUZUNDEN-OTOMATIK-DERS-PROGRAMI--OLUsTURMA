# bolumler/forms.py
from django import forms

class DersProgramiFiltreForm(forms.Form):
    donem_secenekleri = [
        (1, "Güz Dönemi (1-3-5-7)"),
        (2, "Bahar Dönemi (2-4-6-8)"),
    ]
    donem = forms.ChoiceField(
        choices=donem_secenekleri,
        label="Dönem Seçin",
        widget=forms.Select(attrs={"class": "form-control"})
    )
