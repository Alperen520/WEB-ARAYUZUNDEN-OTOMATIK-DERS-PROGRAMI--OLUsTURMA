from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from bolumler.models import Ders, BasarisizDers, OgrenciDersSecimi
from django.contrib import messages

@login_required
def ders_secimi_view(request):
    user = request.user

    # Öğrencinin profilini çek
    ogrenci = user.get_ogrenci_profili()

    if not ogrenci:
        return render(request, "ogrenci/ders_secimi.html", {"hata": "Profil bilgilerinize ulaşılamıyor."})

    # Maksimum ECTS hesapla
    max_ects = 30
    if BasarisizDers.objects.filter(ogrenci=user).exists():
        max_ects = 45

    # Uygun dersler: kendi bölümünden ve döneminden olan dersler
    uygun_dersler = Ders.objects.filter(bolum=ogrenci.bolum, donem=ogrenci.donem)

    # Kaldığı (başarısız) dersleri de göster
    kaldigi_dersler = Ders.objects.filter(basarisizders__ogrenci=user)

    # Toplam uygun ders listesi
    tum_dersler = (uygun_dersler | kaldigi_dersler).distinct()

    # Daha önce seçilmiş dersler
    secili_dersler = OgrenciDersSecimi.objects.filter(ogrenci=ogrenci).values_list('ders_id', flat=True)

    if request.method == "POST":
        secilen_ders_idleri = request.POST.getlist("dersler")
        secilen_dersler = Ders.objects.filter(id__in=secilen_ders_idleri)

        toplam_ects = sum(d.ects for d in secilen_dersler)

        if toplam_ects > max_ects:
            return render(request, "ogrenci/ders_secimi.html", {
                "ogrenci": ogrenci,
                "uygun_dersler": tum_dersler,
                "secili_dersler": secili_dersler,
                "max_ects": max_ects,
                "toplam_ects": toplam_ects,
                "hata": f"Toplam ECTS {max_ects} sınırını aşıyor!"
            })

        # Öncekileri sil
        OgrenciDersSecimi.objects.filter(ogrenci=ogrenci).delete()

        # Yenilerini ekle
        for ders in secilen_dersler:
            alttan_mi = ders in kaldigi_dersler
            OgrenciDersSecimi.objects.create(ogrenci=ogrenci, ders=ders, alttan=alttan_mi)

        messages.success(request, "Ders seçiminiz kaydedildi.")
        return redirect("ogrenci:ders_secimi")

    toplam_ects = sum(Ders.objects.get(id=id).ects for id in secili_dersler)

    return render(request, "ogrenci/ders_secimi.html", {
        "ogrenci": ogrenci,
        "uygun_dersler": tum_dersler,
        "secili_dersler": secili_dersler,
        "max_ects": max_ects,
        "toplam_ects": toplam_ects
    })

