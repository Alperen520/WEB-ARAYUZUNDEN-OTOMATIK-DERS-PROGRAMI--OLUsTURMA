# ogrenci/urls.py
from django.urls import path
from . import views

app_name = 'ogrenci'

urlpatterns = [
    path('ders-secimi/', views.ders_secimi_view, name='ders_secimi'),
  
]

