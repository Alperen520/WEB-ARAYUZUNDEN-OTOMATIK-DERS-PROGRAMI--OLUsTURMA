from django.urls import path
from . import views

app_name = "akademisyen"

urlpatterns = [
        path("ders-onay/", views.ders_secimi_onayla, name="ders_onay"),
        path("ogrenci/<int:ogrenci_id>/", views.ogrenci_ders_detay, name="ogrenci_ders_detay"),
        path("ders-onay/post/", views.ders_secimi_onayla_post, name="ders_onayla_post"),
        path("ders-onay/toplu/", views.ders_toplu_onay, name="ders_toplu_onay"),
        

    # Gerekirse debug için bu da eklenebilir
    #path("debug/", views.debug_onay_sistemi, name="debug_onay"),
]
