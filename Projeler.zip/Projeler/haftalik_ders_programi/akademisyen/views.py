from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q
from bolumler.models import Ogrenci, OgrenciDersSecimi, Ders, SinifSorumlusu, DersSecimOnay
from kullanicilar.models import User

@login_required
def ders_secimi_onayla(request):
    akademisyen = request.user
    sorumluluklar = SinifSorumlusu.objects.filter(akademisyen=akademisyen)

    if not sorumluluklar.exists():
        return render(request, "akademisyen/onay_bekleyen_dersler.html", {
            "hata": "Sorumlusu olduğunuz herhangi bir sınıf bulunamadı."
        })

    query = Q()
    for s in sorumluluklar:
        query |= Q(bolum=s.bolum, donem=s.donem)

    ogrenciler = Ogrenci.objects.filter(query)

    onay_kayitlari = []
    for ogrenci in ogrenciler:
        dersler = OgrenciDersSecimi.objects.filter(ogrenci=ogrenci).select_related("ders")
        if dersler.exists():
            onay_kaydi, _ = DersSecimOnay.objects.get_or_create(ogrenci=ogrenci, akademisyen=akademisyen)
            onay_kayitlari.append({
                "ogrenci": ogrenci,
                "dersler": dersler,
                "onay": onay_kaydi
            })

    return render(request, "akademisyen/onay_bekleyen_dersler.html", {
        "onay_kayitlari": onay_kayitlari
    })

@login_required
def ders_secimi_onayla_post(request):
    if request.method == "POST":
        ogrenci_id = request.POST.get("ogrenci_id")
        islem = request.POST.get("islem")
        akademisyen = request.user
        ogrenci = get_object_or_404(Ogrenci, id=ogrenci_id)

        if islem == "onayla":
            onay_kaydi, _ = DersSecimOnay.objects.get_or_create(ogrenci=ogrenci, akademisyen=akademisyen)
            onay_kaydi.onaylandi = True
            onay_kaydi.save()
            messages.success(request, f"{ogrenci} öğrencisinin ders seçimi onaylandı.")

        elif islem == "sil":
            OgrenciDersSecimi.objects.filter(ogrenci=ogrenci).delete()
            DersSecimOnay.objects.filter(ogrenci=ogrenci, akademisyen=akademisyen).delete()
            messages.warning(request, f"{ogrenci} öğrencisinin ders seçimi silindi.")

    return redirect("akademisyen:ders_onay")

@login_required
def ogrenci_ders_detay(request, ogrenci_id):
    ogrenci = get_object_or_404(Ogrenci, id=ogrenci_id)
    dersler = OgrenciDersSecimi.objects.filter(ogrenci=ogrenci).select_related("ders")

    return render(request, "akademisyen/ogrenci_ders_detay.html", {
        "ogrenci": ogrenci,
        "dersler": dersler
    })

@login_required
def debug_onay_sistemi(request):
    akademisyen = request.user
    print(f"[1] Giriş yapan kullanıcı: {akademisyen.username}")

    sorumluluklar = SinifSorumlusu.objects.filter(akademisyen=akademisyen)
    if not sorumluluklar.exists():
        print("[2] Bu akademisyene atanmış sınıf sorumluluğu yok.")
    else:
        print(f"[2] Sınıf sorumlulukları ({sorumluluklar.count()}):")
        for s in sorumluluklar:
            print(f" - Bölüm: {s.bolum}, Dönem: {s.donem}")

    query = Q()
    for s in sorumluluklar:
        query |= Q(bolum=s.bolum, donem=s.donem)

    ogrenciler = Ogrenci.objects.filter(query)
    if not ogrenciler.exists():
        print("[3] İlgili bölüm ve döneme ait öğrenci bulunamadı.")
    else:
        print(f"[3] Öğrenci sayısı: {ogrenciler.count()}")
        for o in ogrenciler:
            print(f" - {o.numara} | {o.isim} {o.soyisim} | Dönem: {o.donem}")

    secimler = OgrenciDersSecimi.objects.filter(ogrenci__in=ogrenciler)
    if not secimler.exists():
        print("[4] Öğrenciler henüz ders seçimi yapmamış.")
    else:
        print(f"[4] Ders seçimi yapan öğrenci sayısı: {secimler.values('ogrenci').distinct().count()}")
        for secim in secimler:
            print(f" - {secim.ogrenci} → {secim.ders.ad}")

    return render(request, "akademisyen/debug_sonuclari.html", {})

@login_required
def ders_toplu_onay(request):
    akademisyen = request.user
    sorumluluklar = SinifSorumlusu.objects.filter(akademisyen=akademisyen)

    query = Q()
    for s in sorumluluklar:
        query |= Q(bolum=s.bolum, donem=s.donem)

    ogrenciler = Ogrenci.objects.filter(query)
    for ogrenci in ogrenciler:
        if OgrenciDersSecimi.objects.filter(ogrenci=ogrenci).exists():
            onay_kaydi, _ = DersSecimOnay.objects.get_or_create(ogrenci=ogrenci, akademisyen=akademisyen)
            onay_kaydi.onaylandi = True
            onay_kaydi.save()

    messages.success(request, "Tüm öğrencilerin ders seçimleri onaylandı.")
    return redirect("akademisyen:ders_onay")
