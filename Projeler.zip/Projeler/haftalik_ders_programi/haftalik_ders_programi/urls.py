from django.contrib import admin
from django.urls import path, include
from kullanicilar import views

urlpatterns = [
    path("admin/", admin.site.urls),
    path('giris/', views.giris_yap, name='giris'),
    path('cikis/', views.cikis_yap, name='cikis'),
    path('kayit/', views.kayit_ol, name='kayit'),
    path('ogrenci/', include('ogrenci.urls')),
    path('admin-paneli/', views.admin_paneli, name='admin_paneli'),
    path('akademisyen-paneli/', views.akademisyen_paneli, name='akademisyen_paneli'),
    path('ogrenci-paneli/', views.ogrenci_paneli, name='ogrenci_paneli'),
    path('akademisyen/', include('akademisyen.urls')),
    path('', views.anasayfa, name='anasayfa'),  # Anasayfa burada kalabilir
    path('', include('bolumler.urls')),  # En sonda değil, çalışabilir konuma koy
]
