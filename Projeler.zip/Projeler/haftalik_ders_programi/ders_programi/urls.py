from django.urls import path

urlpatterns = [
    # Henüz view yoksa boş kalsın
]
