# views.py
from django.shortcuts import render
from django.http import HttpResponse

def anasayfa(request):
    return HttpResponse("Hoş geldiniz! Kullanıcı girişi yakında burada olacak.")
