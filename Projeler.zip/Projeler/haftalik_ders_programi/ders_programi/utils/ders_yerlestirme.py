# ders_yerlestirme.py
